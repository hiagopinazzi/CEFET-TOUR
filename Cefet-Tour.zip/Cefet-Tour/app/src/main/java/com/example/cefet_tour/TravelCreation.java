package com.example.cefet_tour;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TravelCreation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travel_create);
    }
}