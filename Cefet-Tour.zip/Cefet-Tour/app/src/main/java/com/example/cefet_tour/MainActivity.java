package com.example.cefet_tour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button CreateAccount = (Button) findViewById(R.id.CreateAccount);
        Button AccessAccount = (Button) findViewById(R.id.Login);

        CreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CreateAccount.class));
            }
        });

        EditText LoginEmailInput = (EditText) findViewById(R.id.LoginEmailInput);
        EditText LoginPasswordInput = (EditText) findViewById(R.id.LoginPasswordInput);
        int Input_Size = 1;

        AccessAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (LoginEmailInput.getText().length() < Input_Size) {
                    LoginEmailInput.setError("E-mail inválido.");
                } else if (LoginPasswordInput.getText().length() < Input_Size) {
                    LoginPasswordInput.setError("Senha inválida.");
                } else {
                    //Login permitido

                }
            }
        });
    }
}

